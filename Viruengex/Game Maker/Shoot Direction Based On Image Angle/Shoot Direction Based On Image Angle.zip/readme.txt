Name:
Shoot Direction Based On Image Angle

About:
- Simulates shoot direction based on image angle
- Version which it was made: Game Maker 8.0 Pro

License:
- Example is free to use including the resources except the "image while loading game (not the progress bar)" and "sc_Readme"- May include me or not in credit if included in other project

Page:
http://viruengex.blogspot.com/2012/05/game-maker-shoot-direction-based-on.html

Files:
- readme.txt
- screenshot.JPG
- Shoot Direction Based On Image Angle.gmk

Credit:
- Example created by (aka in cyber) Vsio Stitched