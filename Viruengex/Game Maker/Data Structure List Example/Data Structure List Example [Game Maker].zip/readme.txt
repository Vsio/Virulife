Name:
Data Structure List Example

About:
- Simulates using data structure list.
- Version which it was made: Game Maker 8.0 Pro

License:
- Example is free to use including the resources except the "image while loading game (not the progress bar)" and "sc_Readme"
- May include me or not in credit if included in other project

Page:
http://viruengex.blogspot.com/2012/06/game-maker-data-structure-list-example.html

Files:
- Data Structure List Example.gmk
- readme.txt
- screenshot.JPG

Credit:
- Example created by (aka in cyber) Vsio Stitched