Name:
Vigen�re Cipher (Alphabet)

About:
- Application to encrypt / decrypt plaintext / ciphertext by switching the alphabet based on the keyword or phrases used.
- Written in Java programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/02/java-vigenere-cipher-alphabet.html

Files:
- compile.bat
- Driver.class
- input.txt
- outputDecrypt.txt
- outputDecryptAutoKey.txt
- outputEncrypt.txt
- outputEncryptAutoKey.txt
- readme.txt
- run.bat
> folder packVigenereCipherAlphabet
-- VigenereCipherAlphabet.class
-- VigenereCipherAlphabet.java

Credit:
- Coded by (aka in cyber) Vsio Stitched