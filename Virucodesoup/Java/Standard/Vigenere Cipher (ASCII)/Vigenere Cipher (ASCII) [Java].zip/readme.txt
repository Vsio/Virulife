Name:
Vigen�re Cipher (ASCII)

About:
- Application to encrypt / decrypt plaintext / ciphertext by switching the ASCII based on the keyword or phrases used.
- Written in Java programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/02/java-vigenere-cipher-ascii.html

Files:
- compile.bat
- Driver.class
- input.txt
- outputDecrypt.txt
- outputDecryptAutoKey.txt
- outputEncrypt.txt
- outputEncryptAutoKey.txt
- readme.txt
- run.bat
- vigenereCipher_ASCII_screenshot_1.PNG
- vigenereCipher_ASCII_screenshot_2.PNG
- vigenereCipher_ASCII_screenshot_3.PNG
> folder packVigenereCipherASCII
-- VigenereCipherASCII.class
-- VigenereCipherASCII.java

Credit:
- Coded by (aka in cyber) Vsio Stitched