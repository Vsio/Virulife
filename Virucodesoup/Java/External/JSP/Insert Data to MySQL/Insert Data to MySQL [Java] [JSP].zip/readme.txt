Name:
Insert Data to MySQL

About:
- Shows how to insert data to MySQL database
- Written in Java programming language
- Included External: JSP

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/java-jsp-insert-data-to-mysql.html

Files:
- db_virucodesoup.sql
- index.html
- insertDataToMySQL_screenshot.PNG
- post.jsp
- readme.txt
- view.jsp

Credit:
- Coded by (aka in cyber) Vsio Stitched