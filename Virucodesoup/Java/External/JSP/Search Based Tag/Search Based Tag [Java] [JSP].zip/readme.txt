Name:
Search Based Tag

About:
- Searches result from query based on tag
- Written in Java programming language
- Included External: JSP

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/java-jsp-search-based-tag.html

Files:
- db_virucodesoup.sql
- index.html
- readme.txt
- searchBasedTag_screenshot.PNG
- searchTagResut.jsp

Credit:
- Coded by (aka in cyber) Vsio Stitched