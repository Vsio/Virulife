Name:
User Input : Text

About:
- Simulates result from User Input from Text field in JSP
- Written in Java programming language
- Included External: JSP

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/java-jsp-user-input-text.html

Files:
- compile.bat
- UserInputText.java
- index.jsp
- readme.txt
- result.jsp
- userInput_screenshot.PNG
> folder packviru
	-- UserInputText.class

Credit:
- Coded by (aka in cyber) Vsio Stitched