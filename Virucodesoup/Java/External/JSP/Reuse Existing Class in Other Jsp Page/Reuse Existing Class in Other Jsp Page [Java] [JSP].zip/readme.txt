Name:
Reuse Existing Class in Other Jsp Page

About:
- Simulates how to keep and reuse java class between pages.
- Written in Javaprogramming language
- Included External: JSP

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/java-jsp-reuse-existing-class-in-other.html

Files:
- change.jsp
- compile.bat
- index.jsp
- page1.jsp
- page2.jsp
- readme.txt
- reuseClass_screenshot.PNG
- SomeClass.java
> folder packviru
	-- SomeClass.class

Credit:
- Coded by (aka in cyber) Vsio Stitched