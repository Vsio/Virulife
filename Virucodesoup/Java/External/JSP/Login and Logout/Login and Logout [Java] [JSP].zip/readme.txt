Name:
Login and Logout

About:
- Shows how to login and logout
- Written in Java programming language
- Included External: JSP

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/java-jsp-login-and-logout.html

Files:
- db_virucodesoup.sql
- dislike.jsp
- doLogin.jsp
- doLogout.jsp
- index.jsp
- like.jsp
- loginAndLogout_screenshot.PNG
- profile.jsp
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched