Name:
Draw Rhombus with Text

About:
- Small application for drawing rhombus shape using text
- Written in Java programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2011/11/java-draw-rhombus-with-text.html

Files:
- compile.bat
- drawRhombusWithText_Screenshot_1.PNG
- drawRhombusWithText_Screenshot_2.PNG
- drawRhombusWithText_Screenshot_3.PNG
- Driver.class
- Driver.java
- makePackage.bat
- readme.txt
- remakePackage.bat
- run.bat
folder drawRhombusWithText :
   - Rhombus.class
   - Rhombus.java 

Credit:
- Coded by (aka in cyber) Vsio Stitched
- Problem case inspired from my past in high school