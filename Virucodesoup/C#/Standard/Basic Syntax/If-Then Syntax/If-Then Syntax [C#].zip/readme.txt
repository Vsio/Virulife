Name:
If-Then Syntax

About:
- Shows how to do If-Then statement in C#
- Written in C# programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/cs-if-then-syntax.html

Files:
- ifThen.cs
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched