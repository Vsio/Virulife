Name:
String Replacer

About:
- Replaces string
- Written in C# programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/06/cs-string-replacer.html

Files:
- input.txt
- makefile.bat
- output.txt
- readme.txt
- stringReplacer.cs
- StringReplacer.exe
- stringReplacer_screenshot.PNG

Credit:
- Coded by (aka in cyber) Vsio Stitched