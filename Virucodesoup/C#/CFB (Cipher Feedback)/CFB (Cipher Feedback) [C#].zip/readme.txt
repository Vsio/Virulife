Name:
CFB (Cipher Feedback)

About:
- Encrypts/decrypts data with CFB (Cipher Feedback) method.
- Written in C# programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/cs-cfb-cipher-feedback.html

Files:
- cfb.cs
- CFB.exe
- cfb_screenshot.PNG
- input.txt
- iv.txt
- makefile.bat
- output_decipher.txt
- output_encipher.txt
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched