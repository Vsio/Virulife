Name:
ECB (Electronic Code Book)

About:
- Encrypts/decrypts data with ECB (Electronic Code Book) method.
- Written in C# programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/cs-ecb-electronic-code-book.html

Files:
- ecb.cs
- ECB.exe
- ecb_screenshot.PNG
- input.txt
- makefile.bat
- output_decipher.txt
- output_encipher.txt
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched