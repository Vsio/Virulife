Name:
Factorial

About:
- Does factorial calculation
- Written in PHP programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/php-factorial.html

Files:
- factorial.php
- factorial_screenshot.PNG
- index.php
- post.php
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched