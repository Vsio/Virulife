<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
	<?php

	/* ===========================
	// File : index.php
	//
	// Credit:
	// - Coded by (aka in cyber) Vsio Stitched
	//
	// Misc:
	// - Written in PHP programming language
	//
	// License:
	// - Free to use
	// - May include me or not in credit if included in other project
	// =========================== */
	
	?>
		
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Factorial</title>
		
	</head>
	<body>
		
		<div style="font-weight:bold">Factorial</div><br/>
		<form name="f_factorial" action="post.php" method="post">
			<span>Input: <input name="input" type="text" /></span><br/><br/>
			<span><input name="submit" type="submit" value="Do Factorial" /></span>
		</form>
		
	</body>
</html>