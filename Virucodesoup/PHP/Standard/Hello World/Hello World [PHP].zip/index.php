<?php

/* ===========================
// File : index.php
//
// Credit:
// - Coded by (aka in cyber) Vsio Stitched
//
// Misc:
// - Written in PHP programming language
//
// License:
// - Free to use
// - May include me or not in credit if included in other project
// =========================== */

require("helloWorld.php");

echo sayHelloWorld();

?>