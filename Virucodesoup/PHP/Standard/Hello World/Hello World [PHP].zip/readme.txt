Name:
Hello World

About:
- Just saying Hello World
- Written in PHP programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/php-hello-world.html

Files:
- helloWorld.php
- index.php
- helloWorld_screenshot.PNG
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched