Name:
Hello World

About:
- Just a simple program to say Hello World
- Written in Assembly (MIPS) programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
- http://virucodesoup.blogspot.com/2012/02/assembly-mips-hello-world.html

Files:
- helloWorld.asm
- helloWorld_screenshot.PNG
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched