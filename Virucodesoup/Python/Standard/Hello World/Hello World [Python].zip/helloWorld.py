# ===========================
# File : helloWorld.py
#
# Credit:
# - Coded by (aka in cyber) Vsio Stitched
#
# Misc:
# - Written in Python programming language
#
# License:
# - Free to use
# - May include me or not in credit if included in other project
# ===========================

print "Hello World!";
var = raw_input("");