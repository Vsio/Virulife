# ===========================
# File : driver.py
#
# Credit:
# - Coded by (aka in cyber) Vsio Stitched
#
# Misc:
# - Written in Python programming language
#
# License:
# - Free to use
# - May include me or not in credit if included in other project
# ===========================

from factorial import factorial


print "\n===== FACTORIAL =====\n"

print "\n\n== START PROGRAM ==\n\n"

print "Input a number: ",

value = raw_input("");

print factorial(value);

print "\n\n== END PROGRAM ==\n\n"

raw_input("");