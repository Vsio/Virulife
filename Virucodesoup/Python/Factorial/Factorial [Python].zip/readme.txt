Name:
Factorial

About:
- Factorial Simulation
- Written in Python programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/python-factorial.html

Files:
- driver.py
- factorial.py
- factorial_sceenshot.PNG
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched