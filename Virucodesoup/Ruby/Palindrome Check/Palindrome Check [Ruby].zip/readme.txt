Name:
Palindrome Check

About:
- Check whether a string is a palindrome
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/ruby-palindrome-check.html

Files:
- driver.rb
- palindromeCheck.rb
- palindromeCheck_sceenshot.PNG
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched