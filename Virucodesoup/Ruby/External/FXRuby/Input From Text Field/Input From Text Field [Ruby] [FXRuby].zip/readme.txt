Name:
Input From Text Field

About:
- Take input from text field
- Written in Ruby programming language
- Included External: FXRuby

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-fxruby-input-from-text-field.html

Files:
- driver.rb
- inputFromTextField.PNG
- inputFromTextField.rb
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched