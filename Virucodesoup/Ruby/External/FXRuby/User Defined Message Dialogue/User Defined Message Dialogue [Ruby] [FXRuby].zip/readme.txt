Name:
User-Defined Message Dialogue

About:
- Shows user-defined message dialogue
- Written in Ruby programming language
- Included External: FXRuby

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-fxruby-user-defined-message.html

Files:
- driver.rb
- readme.txt
- run.bat
- userDefinedMessageDialogue.rb
- userDefinedMessageDialogue_screenshot.PNG

Credit:
- Coded by (aka in cyber) Vsio Stitched