Name:
Write (Save) File

About:
- Saving/Writing input to a file
- Written in Ruby programming language
- Included External: FXRuby

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-fxruby-write-save-file.html

Files:
- driver.rb
- writeSaveFile_screenshot.PNG
- readme.txt
- run.bat
- writeSaveFile.rb

Credit:
- Coded by (aka in cyber) Vsio Stitched