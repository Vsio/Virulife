Name:
ROT13

About:
- ROT13 simulation
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/ruby-rot13.html

Files:
- driver.rb
- input.txt
- output.txt
- readme.txt
- rot13.rb
- rot13_sceenshot.PNG
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched