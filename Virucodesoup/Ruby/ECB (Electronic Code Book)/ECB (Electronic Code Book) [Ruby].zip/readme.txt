Name:
ECB (Electronic Code Book)

About:
- Encrypts/decrypts data with ECB (Electronic Code Book) method.
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/ruby-ecb-electronic-code-book.html

Files:
- driver.cpp
- ecb.rb
- ecb_screenshot.png
- input.txt
- output_decipher.txt
- output_encipher.txt
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched