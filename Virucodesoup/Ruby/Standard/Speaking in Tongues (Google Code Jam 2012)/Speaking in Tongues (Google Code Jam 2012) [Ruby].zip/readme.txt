Name:
Speaking in Tongues (Google Code Jam 2012)

About:
- Solves Speaking in Tongues (Google Code Jam 2012) problem
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-speaking-in-tongues-google-code.html

Files:
- A-small-attempt0.in
- driver.rb
- gjs_SpeakingInTongues.rb
- input.txt
- readme.txt
- run.bat
- solution_input.txt
- Speaking_in_Toungues_example.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched
- Problem case and example (in A-small-attempt0.in and Speaking_in_Toungues_example.txt) from Google Code Jam 2012 Qualification Round (http://code.google.com/codejam/contest/1460488/dashboard#s=p0)