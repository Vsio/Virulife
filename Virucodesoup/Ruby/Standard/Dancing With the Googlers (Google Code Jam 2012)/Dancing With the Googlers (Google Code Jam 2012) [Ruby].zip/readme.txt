Name:
Dancing With the Googlers (Google Code Jam 2012)

About:
- Solves Dancing With the Googlers (Google Code Jam 2012) problem
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-dancing-with-googlers-google-code.html

Files:
- A-small-attempt0.in
- driver.rb
- gcj_SpeakingInTongues.PNG
- gcj_SpeakingInTongues.rb
- input.txt
- readme.txt
- run.bat
- solution_input.txt
- Speaking_in_Toungues_example.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched
- - Problem case and example (in B-small-attempt0.in, B-large.in, and Dancing_With_the_Googlers_example.txt) from Google Code Jam 2012 Qualification Round (http://code.google.com/codejam/contest/1460488/dashboard#s=p1)