Name:
Rail Fence Cipher Extended

About:
- Simulates Rail Fence Cipher Extended encryption
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/ruby-rail-fence-cipher-extended.html

Files:
- driver.rb
- input.txt
- output_decipher.txt
- output_encipher.txt
- railFenceCipherExtended.rb
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched