Name:
OCB (Output Feedback)

About:
- Encrypts/decrypts data with OFB (Output Feedback) method.
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/ruby-ofb-output-feedback.html

Files:
- driver.rb
- ofb.rb
- ofb_screenshot.png
- input.txt
- iv.txt
- output_decipher.txt
- output_encipher.txt
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched