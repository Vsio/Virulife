Name:
Random Choice With Hash Table

About:
- Shows how to choose output from hash table with random selection
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-random-choice-with-hash-table.html

Files:
- driver.rb
- randomChoice_srceenshot.PNG
- randomChoiceWithHashTable.rb
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched