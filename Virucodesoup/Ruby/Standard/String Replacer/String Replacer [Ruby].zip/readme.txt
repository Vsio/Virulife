Name:
String Replacer

About:
- Replaces string
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/06/ruby-string-replacer.html

Files:
- driver.rb
- input.txt
- output.txt
- readme.txt
- run.bat
- stringReplacer.rb
- stringReplacer_screenshot.PNG

Credit:
- Coded by (aka in cyber) Vsio Stitched