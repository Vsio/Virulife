Name:
CFB (Cipher Feedback)

About:
- Encrypts/decrypts data with CFB (Cipher Feedback) method.
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/ruby-cfb-cipher-feedback.html

Files:
- driver.rb
- cfb.rb
- cfb_screenshot.png
- input.txt
- iv.txt
- output_decipher.txt
- output_encipher.txt
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched