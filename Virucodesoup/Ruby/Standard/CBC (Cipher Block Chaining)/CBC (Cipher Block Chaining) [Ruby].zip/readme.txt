Name:
CBC (Cipher-Block Chaining)

About:
- Encrypts/decrypts data with CBC (Cipher-Block Chaining) method.
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/ruby-cbc-cipher-block-chaining.html

Files:
- driver.rb
- cbc.rb
- cbc_screenshot.png
- input.txt
- iv.txt
- output_decipher.txt
- output_encipher.txt
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched