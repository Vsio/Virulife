Name:
Case Syntax

About:
- Shows how to do Case statement in Ruby
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-case-syntax.html

Files:
- case.rb
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched