# ===========================
# File : function.rb
#
# Credit:
# - Coded by (aka in cyber) Vsio Stitched
#
# Misc:
# - Written in Ruby programming language
#
# License:
# - Free to use
# - May include me or not in credit if included in other project
# ===========================

# This is to do Function block. In ruby, you can use "def". You also must put "return" so the function will return value.

def add(_number1,_number2) 
	# Do _number1+_number2
	
	return (_number1+_number2) # output of function
end

puts add(19,81) # prints result: 100

gets # pauses command so it doesn't exit immediately
