# ===========================
# File : procedure.rb
#
# Credit:
# - Coded by (aka in cyber) Vsio Stitched
#
# Misc:
# - Written in Ruby programming language
#
# License:
# - Free to use
# - May include me or not in credit if included in other project
# ===========================

# This is to do Procedure block. In ruby, you can use "def". The difference with Function is that you don't use return, but the "def" itself will not return value

def printNumber(_number)
	# prints number into display
	
	print "The number is ",_number,"\n"
end

printNumber(101)

gets
