Name:
Procedure Syntax

About:
- Shows how to do Procedure statement in Ruby
- Written in Ruby programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ruby-procedure-syntax.html

Files:
- procedure.rb
- readme.txt
- run.bat

Credit:
- Coded by (aka in cyber) Vsio Stitched