Name:
ECB (Electronic Code Book)

About:
- Encrypts/decrypts data with ECB (Electronic Code Book) method.
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/cpp-ecb-electronic-code-book.html

Files:
- driver.cpp
- ecb.cpp
- ECB.exe
- ecb.hpp
- ecb_decrypt.txt
- ecb_encrypt.txt
- ecb_screenshot.PNG
- input.txt
- makefile.bat
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched