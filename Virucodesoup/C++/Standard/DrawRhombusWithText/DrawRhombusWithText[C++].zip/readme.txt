Name:
Draw Rhombus with Text

About:
- Small application for drawing rhombus shape using text
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2011/11/cpp-draw-rhombus-with-text.html

Files:
- drawRhombusWithText.cpp
- DrawRhombusWithText.exe
- drawRhombusWithText.hpp
- drawRhombusWithText_screenshot_1.PNG
- drawRhombusWithText_screenshot_2.PNG
- drawRhombusWithText_screenshot_3.PNG
- driver.cpp
- makefile
- makefile.bat
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched
- Problem case inspired from my past in high school