Name:
Frequency Analysis (Alphabet)

About:
- Application to count the frequency of groups of letters.
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/02/cpp-frequency-analysis-alphabet.html

Files:
- driver.cpp
- Frequency Analysis Alphabet.exe
- frequencyAnalysis_Alphabet.cpp
- frequencyAnalysis_Alphabet.hpp
- frequencyAnalysis_Alphabet_screenshot_1.PNG
- frequencyAnalysis_Alphabet_screenshot_2.PNG
- frequencyAnalysis_Alphabet_screenshot_3.PNG
- input.txt
- makefile.bat
- output.txt
- readme.txt
-> folder Storer
-- driver.cpp
-- makefile.bat
-- storer.cpp
-- Storer.exe
-- storer.hpp


Credit:
- Coded by (aka in cyber) Vsio Stitched