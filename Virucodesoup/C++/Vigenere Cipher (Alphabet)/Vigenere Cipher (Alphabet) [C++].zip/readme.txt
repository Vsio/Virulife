Name:
Vigen�re Cipher (Alphabet)

About:
- Application to encrypt / decrypt plaintext / ciphertext by switching the alphabet based on the keyword or phrases used.
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/02/cpp-vigenere-cipher-alphabet.html

Files:
- driver.cpp
- input.txt
- makefile
- makefile.bat
- outputDecrypt.txt
- outputDecryptAutoKey.txt
- outputEncrypt.txt
- outputEncryptAutoKey.txt
- readme.txt
- Vigenere Cipher (Alphabet).exe
- vigenereCipher_Alphabet.cpp
- vigenereCipher_Alphabet.hpp
- vigenereCipher_Alphabet_screenshot_1.PNG
- vigenereCipher_Alphabet_screenshot_2.PNG
- vigenereCipher_Alphabet_screenshot_3.PNG


Credit:
- Coded by (aka in cyber) Vsio Stitched