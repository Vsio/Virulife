Name:
Caesar Cipher (Alphabet)

About:
- Application to encrypt / decrypt plaintext / ciphertext by switching the alphabet based its index to another alphabet index number key
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/01/cpp-caesar-cipher-alphabet.html

Files:
- Caesar Cipher (Alphabet).exe
- caesarCipher_Alphabet.cpp
- caesarCipher_Alphabet.hpp
- caesarCipher_Alphabet_screenshot_1.PNG
- caesarCipher_Alphabet_screenshot_2.PNG
- caesarCipher_Alphabet_screenshot_3.PNG
- driver.cpp
- input.txt
- makefile
- makefile.bat
- outputDecrypt.txt
- outputDecryptExhaustiveKeySearch.txt
- outputEncrypt.txt
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched