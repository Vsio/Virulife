Name:
Alphabet Soup (Facebook Hacker Cup 2012)

About:
- Application to count how many HACKERCUP word can be created from H, A, C, K, E, R, U, and P letters received
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/01/cpp-alphabet-soup-facebook-hacker-cup.html

Files:

- alphabet_soup.txt
- alphabet_soup_example.txt
- driver.cpp
- FBH2012_AlphabetSoup.cpp
- FBH2012_AlphabetSoup.exe
- FBH2012_AlphabetSoup.hpp
- FBH2012_AlphabetSoup_screenshot_1.PNG
- FBH2012_AlphabetSoup_screenshot_2.PNG
- FBH2012_AlphabetSoup_screenshot_3.PNG
- input.txt
- makefile
- makefile.bat
- output.txt
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched
- Problem case and example (in alphabet_soup.txt and alphabet_soup_example.txt) from Facebook Hacker Cup 2012 Qualification Round ( https://www.facebook.com/hackercup/problems.php?pid=341666075863455&round=146094915502528 )