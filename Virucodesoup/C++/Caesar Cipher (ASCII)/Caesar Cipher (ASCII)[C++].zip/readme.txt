Name:
Caesar Cipher (ASCII)

About:
- Application to encrypt / decrypt plaintext / ciphertext by switching the ASCII based on its index to other ASCII based on its index.
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/02/cpp-caesar-cipher-ascii.html

Files:
- Caesar Cipher (ASCII).exe
- caesarCipher_ASCII.cpp
- caesarCipher_ASCII.hpp
- caesarCipher_ASCII_screenshot_1.PNG
- caesarCipher_ASCII_screenshot_2.PNG
- caesarCipher_ASCII_screenshot_3.PNG
- driver.cpp
- input.txt
- makefile
- makefile.bat
- outputDecrypt.txt
- outputDecryptExhaustiveKeySearch.txt
- outputEncrypt.txt
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched