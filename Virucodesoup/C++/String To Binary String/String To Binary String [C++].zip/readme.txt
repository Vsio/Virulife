Name:
String To Binary String

About:
- A Converts a String into Binary String.
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/03/cpp-string-to-binary-string.html

Files:
- driver.cpp
- makefile.bat
- output.txt
- readme.txt
- String To Binary String.exe
- stringToBinaryString.cpp
- stringToBinaryString.hpp

Credit:
- Coded by (aka in cyber) Vsio Stitched