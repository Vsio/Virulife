Name:
Vigen�re Cipher (ASCII)

About:
- Application to encrypt / decrypt plaintext / ciphertext by switching the ASCII based on the keyword or phrases used.
- Written in C++ programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/02/cpp-vigenere-cipher-ascii.html

Files:
- driver.cpp
- input.txt
- makefile
- makefile.bat
- outputDecrypt.txt
- outputDecryptAutoKey.txt
- outputEncrypt.txt
- outputEncryptAutoKey.txt
- readme.txt
- Vigenere Cipher (ASCII).exe
- vigenereCipher_ASCII.cpp
- vigenereCipher_ASCII.hpp
- vigenereCipher_ASCII_screenshot_1.PNG
- vigenereCipher_ASCII_screenshot_2.PNG
- vigenereCipher_ASCII_screenshot_3.PNG


Credit:
- Coded by (aka in cyber) Vsio Stitched