Name:
Content Based Radio Choice

About:
- Simulates how to generate content based on the choice of radio button
- Written in Javascript programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
- http://virucodesoup.blogspot.com/2012/03/javascript-content-based-radio-choice.html

Files:
- contentBasedRadioChoice.js
- contentBasedRadioChoice_screenshot_1.PNG
- contentBasedRadioChoice_screenshot_2.PNG
- driver.html
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched