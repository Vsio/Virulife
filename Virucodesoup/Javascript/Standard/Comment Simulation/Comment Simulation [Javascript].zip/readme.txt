Name:
Comment Simulation

About:
- Simulation of comment
- Written in Javascript programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
- http://virucodesoup.blogspot.com/2012/03/javascript-comment-simulation.html

Files:
- comment.js
- commentSimulation_screenshot_1.PNG
- commentSimulation_screenshot_2.PNG
- driver.html
- listOfComments.js
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched