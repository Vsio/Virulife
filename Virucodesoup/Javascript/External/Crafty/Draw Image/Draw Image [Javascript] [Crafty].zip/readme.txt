Name:
Draw Image

About:
- Shows how to draw image
- Written in Javascript programming language
- Included Extension: Crafty

License:
- Free to use
- May include me or not in credit if included in other project

Page:
- http://virucodesoup.blogspot.com/2012/04/javascript-crafty-draw-image.html

Files:
- 20110811.PNG
- driver.js
- drawImage.js
- drawImage_screenshot.PNG
- index.html
- readme.txt


Credit:
- Coded by (aka in cyber) Vsio Stitched