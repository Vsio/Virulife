Name:
Text Example

About:
- Shows how to display text
- Written in Javascript programming language
- Included Extension: Crafty

License:
- Free to use
- May include me or not in credit if included in other project

Page:
- http://virucodesoup.blogspot.com/2012/04/javascript-crafty-text-example.html

Files:
- driver.js
- index.html
- readme.txt
- textExample.js
- textExample_screenshot.PNG

Credit:
- Coded by (aka in cyber) Vsio Stitched