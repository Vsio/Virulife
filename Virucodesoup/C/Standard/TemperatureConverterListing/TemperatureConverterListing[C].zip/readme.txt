Name:
Temperature Converter Listing

About:
Small application for listing temperature in Celcius, Reaumur, and Fahrenheit

License:
- Free to use
- May include me or not in credit

Page:
http://virucodesoup.blogspot.com/2011/11/c-temperature-converter-listing.html

Files:
- makefile
- makefile.bat
- mTmperatureConverterListing.c
- temperatureConverterListing.h
- temperatureConverterListing.c
- TemperatureConverterListing.exe
- temperatureConverterListing_screenshot_1.PNG
- temperatureConverterListing_screenshot_2.PNG
- temperatureConverterListing_screenshot_3.PNG

Credit:
- Coded by (aka in cyber) Vsio Stitched.
- Problem case inspired from >> http://www.cprogramming.com/challenges/celsius_converter_table.html