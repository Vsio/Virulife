Name:
Temperature Converter Listing

About:
Small application for listing temperature in Celcius, Reaumur, and Fahrenheit

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2011/11/ada-temperature-converter-listing.html

Files:
- Driver.adb
- driver.ali
- driver.exe
- driver.o
- makefile
- makefile.bat
- readme.txt
- TemperatureConverterListing.adb
- TemperatureConverterListing.ads
- temperatureConverterListing_screenshot_1.PNG
- temperatureConverterListing_screenshot_2.PNG
- temperatureConverterListing_screenshot_3.PNG
- temperatureconverterlisting.ali
- temperatureconverterlisting.o

Credit:
- Coded by (aka in cyber) Vsio Stitched.
- Problem case inspired from >> http://www.cprogramming.com/challenges/celsius_converter_table.html