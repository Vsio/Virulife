Name:
If-Then Syntax

About:
- Shows how to do If-Then statement in Ada
- Written in Ada programming language

License:
- Free to use
- May include me or not in credit if included in other project

Page:
http://virucodesoup.blogspot.com/2012/04/ada-if-then-syntax.html

Files:
- ifThen.adb
- makefile.bat
- readme.txt

Credit:
- Coded by (aka in cyber) Vsio Stitched