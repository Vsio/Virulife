To the "[Number]-[Date]-Notilen.txt":
- Replaces [Number] to the sequence of discussion
- Replaces [Date] to the YYYYMMDD with YYYY is year, MM is month, and DD is the day