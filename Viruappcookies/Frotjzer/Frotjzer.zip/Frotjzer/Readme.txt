Frotzer is a project management template. It makes easier and consistent to manage the project. 
The word Frotzer itself comes from combination and distorsion.
It is:
- "F-" from Folder, the "F-" there is taken
- "-ro-" from Project, the "-ro-" there is taken
- "-ze-" from Management, the "ge" when it is read, it sounds like "je" so I distorted it a little into "-ze"
- The other unmentioned letters, comes from distortion, trying makes the words sound like "Frozen"

The Frotzer itself, is a modified version of G-Projer I made long ago. Since recently I am dealing with non-game-related project, I decided to make the more generalized version. I also added more features to this template (Reminds me to add it to the G-Projer to later).


The category of Frotzer is:

1. [ProjectName] : This will be folder for storing the project files. Removes the '[' and ']'
2. Concept : useful for storing information and image regarding concept of the project
3. Resource : This is for storing the resource for the game but not used yet.
4. Request : This is for requesting something related to project from someone (i.e.: Doing the graphic, finding resource, etc.)
5. Reference : This is for tutorial, competition page, and any related kind.

To use it, all you need is to copy the [ProjectName] (not the Frotzer folder) then put it in the folder you like. Then, you can start your project.

You can add more folder as category on your own since this folder itself serves as customable template.